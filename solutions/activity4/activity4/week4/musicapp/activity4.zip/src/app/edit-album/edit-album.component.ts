import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-album',
  templateUrl: './edit-album.component.html',
  styleUrl: './edit-album.component.css'
})
export class EditAlbumComponent {

}
